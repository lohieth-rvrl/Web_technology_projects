let currentQuestion = 1;
let score = 0;

function checkAnswer(questionNumber, isCorrect) {
    if (isCorrect) {
        score++;
    }

    document.getElementById('question' + questionNumber).classList.remove('show');
    document.getElementById('question' + questionNumber).classList.add('hidden');

    currentQuestion++;

    if (currentQuestion <= 3) {
        const nextQuestion = document.getElementById('question' + currentQuestion);
        nextQuestion.classList.remove('hidden');
        nextQuestion.classList.add('show');
    } else {
        showResult();
    }
}

function showResult() {
    document.getElementById('result-container').classList.remove('hidden');
    document.getElementById('score').innerText = `${score} / 3`;
}
